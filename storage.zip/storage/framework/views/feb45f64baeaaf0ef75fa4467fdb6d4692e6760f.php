<?php $__env->startSection('title', 'Início'); ?>

<?php $__env->startSection('content'); ?>
    <section class="col-xs-12 col-sm-7">
        <article class="content-wrap">
            <header class="content-title-wrap">
                <h1 class="content-title">inicio</h1>
            </header>
        </article>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>