<?php 
    $schedules = [
        "01:00" => [
            "Polo 001" => [ "Categoria 001" ]
        ],
        "02:00" => [
            "Polo 002" => [ "Categoria 002" ],
            "Polo 004" => [ "Categoria 004" ]
        ],
        "03:00" => [
            "Polo 003" => [
                "Categoria 003",
                "Categoria 004"
            ],
        ],
        "04:00" => [
            "Polo 004" => [ "Categoria 004" ]
        ],
        "05:00" => [
            "Polo 001" => [ "Categoria 001" ],
            "Polo 003" => [
                "Categoria 003",
                "Categoria 004"
            ],
            "Polo 005 " => [ "Categoria 005" ]
        ]
    ];

    $days = [
        'mon' => "SEG",
        'tue' => "TER",
        'Wed' => "QUA",
        'thu' => "QUI",
        'fri' => "SEX",
        'sat' => "SÁB"
    ]
 ?>
<section class="sidebar col-sm-4 col-md-3 hidden-xs">
    <div class="sidebar-schedule sidebar-wrap">
        <header class="schedule-header sidebar-list-item">
            <h1 class="schedule-title">Horários</h1>
            <ul class="schedule-nav nav nav-justified">
                <?php $__currentLoopData = $days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day => $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li>
                      <a class="schedule-nav-content" href="#schedule-<?php echo e($day); ?>"><?php echo e($title); ?></a>
                  </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </header>
        <table class="schedule table">
          <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hour=>$poles): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php  $numPoles = count($poles);  ?>
            <tr>
              <?php if($numPoles == 1): ?>
                <td class="schedule-item schedule-item--bordered schedule-hour">
              <?php else: ?>
                <td class="schedule-item schedule-item--bordered schedule-hour" rowspan="<?php echo e($numPoles); ?>">
              <?php endif; ?>
                <div class="schedule-hour--content"><?php echo e($hour); ?></div>
              </td>
              <?php  $c = 0;  ?>
              <?php $__currentLoopData = $poles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pole => $categories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php  $scheduleItemClass = "schedule-item schedule-category";  ?>

                <?php if($numPoles == 1): ?>
                  <?php  $scheduleItemClass .= " schedule-item--bordered";  ?>
                <?php endif; ?>


                <?php if($c == 0): ?>
                  <?php  $scheduleItemClass .= " schedule-item--first";  ?>
                <?php else: ?>
                  </tr>
                  <tr>
                <?php endif; ?>
                <td class="<?php echo e($scheduleItemClass); ?>">
                  <div class="schedule-category--pole"><?php echo e($pole); ?></div>
                  <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="schedule-category--name"><?php echo e($category); ?></div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <?php  $c++;  ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
</section>
