@extends('layout.app')

@section('title', 'Início')

@section('content')
    <section class="col-xs-12 col-sm-8 col-md-9">
        <article class="content-wrap">
            <header class="content-title-wrap">
                <h1 class="content-title">inicio</h1>
            </header>
        </article>
    </section>
@endsection
